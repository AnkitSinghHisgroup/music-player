const LikedSongs = (props) => {
    return ( 
        <div>
            <h1>LikedSongs</h1>
        </div>
     );
}
 
export default LikedSongs;