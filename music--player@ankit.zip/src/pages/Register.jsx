const Register = () => {
    return ( 
        <div>
            
        </div>
     );
}
 
export default Register;